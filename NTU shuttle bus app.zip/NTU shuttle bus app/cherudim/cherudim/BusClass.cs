﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cherudim
{
    public class BusStop
    {
        public string busType { get; set; }
        public string busStopID { get; set; }
        public string busStopDetails { get; set; }
        public string busStopUri { get; set; }
        //public string busRemainingTime { get; set; }

        public BusStop(string inBusType, string inBusStopID, string inBusStopDetails, string inBusStopUri)
        {
            busType = inBusType;
            busStopID = inBusStopID;
            busStopDetails = inBusStopDetails;
            busStopUri = inBusStopUri;
        }
    }

    public class FavBusStop
    {
        public string busType { get; set; }
        public string busStopID { get; set; }
        public string busStopDetails { get; set; }
        public string busStopUri { get; set; }
    }

    public class BusStops
    {
        public string listName;

        public List<BusStop> busStopList;

        public BusStops(string inListName)
        {
            listName = inListName;

            busStopList = new List<BusStop>();

            switch (listName)
            {
                case "A":
                    if (busStopList.Count != 0)
                    {
                        busStopList.Clear();
                    }

                    busStopList.Add(new BusStop("A", "27281", "Hall 1", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/3/27281/"));
                    busStopList.Add(new BusStop("A", "27291", "Opposite Hall 6", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/4/27291/"));
                    busStopList.Add(new BusStop("A", "27311", "Hall 2", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/5/27311/"));
                    busStopList.Add(new BusStop("A", "63739", "School of ADM", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/6/63739/"));
                    busStopList.Add(new BusStop("A", "27211", "Lee Wee Nam Library", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/7/27211/"));
                    busStopList.Add(new BusStop("A", "27221", "School of CEE", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/8/27221/"));
                    busStopList.Add(new BusStop("A", "63741", "School of Biological Sciences", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/9/63741/"));
                    busStopList.Add(new BusStop("A", "27231", "School of Comms Studies", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/10/27231/"));
                    busStopList.Add(new BusStop("A", "27241", "Hall 7", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/11/27241/"));
                    busStopList.Add(new BusStop("A", "27251", "Innovation Centre", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/12/27251/"));
                    busStopList.Add(new BusStop("A", "27261", "Hall 4", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/1/27261/"));
                    busStopList.Add(new BusStop("A", "63747", "Hall 5", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/2/63747/"));
                    break;

                case "B":
                    if (busStopList.Count != 0)
                    {
                        busStopList.Clear();
                    }

                    busStopList.Add(new BusStop("B", "27011", "Grad Hall and Hall 11", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/2/15/27011/"));
                    busStopList.Add(new BusStop("B", "27021", "Hall 14 and Hall 15", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/2/16/27021/"));
                    busStopList.Add(new BusStop("B", "27031", "Hall 12 and Hall 13", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/2/17/27031/"));
                    busStopList.Add(new BusStop("B", "27041", "NIE Carpark Y", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/2/18/27041/"));
                    busStopList.Add(new BusStop("B", "27051", "NIE Library", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/2/19/27051/"));
                    busStopList.Add(new BusStop("B", "27219", "Opposite Lee Wee Nam Library", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/2/20/27219/"));
                    busStopList.Add(new BusStop("B", "27069", "Opposite School of ADM", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/2/21/27069/"));
                    busStopList.Add(new BusStop("B", "27209", "Hall 8 and Hall 9", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/2/13/27209/"));
                    busStopList.Add(new BusStop("B", "27199", "Hall 10 and Hall 11", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/2/14/27199/"));
                    break;

                case "C":
                    if (busStopList.Count != 0)
                    {
                        busStopList.Clear();
                    }

                    busStopList.Add(new BusStop("C", "63731", "Opposite Hall 5 and Hall 4", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/36/63731/"));
                    busStopList.Add(new BusStop("C", "63701", "Opposite Innovation Centre", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/22/63701/"));
                    busStopList.Add(new BusStop("C", "63703", "School of SPMS", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/23/63703/"));
                    busStopList.Add(new BusStop("C", "63705", "Hall 7 and Opposite Block S2", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/24/63705/"));
                    busStopList.Add(new BusStop("C", "63707", "Opposite School of Comms Studies", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/25/63707/"));
                    busStopList.Add(new BusStop("C", "63709", "Opposite School of Biological Sciences", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/39/63709/"));
                    busStopList.Add(new BusStop("C", "63711", "Opposite School of CEE", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/26/63711/"));
                    busStopList.Add(new BusStop("C", "27219", "Opposite Lee Wee Nam Library", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/20/27219/"));
                    busStopList.Add(new BusStop("C", "63713", "Opposite Hall 3 and Hall 16", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/27/63713/"));
                    busStopList.Add(new BusStop("C", "63715", "Opposite Hall 12 and Hall 13", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/28/63715/"));
                    busStopList.Add(new BusStop("C", "63717", "Opposite Hall 14 and Hall 15", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/29/63717/"));
                    busStopList.Add(new BusStop("C", "63719", "Opposite Grad Hall and Hall 11", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/30/63719/"));
                    busStopList.Add(new BusStop("C", "63721", "Opposite Hall 10 and Hall 11", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/31/63721/"));
                    busStopList.Add(new BusStop("C", "63723", "Nanyang Heights, Opposite Hall 8 and Hall 9", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/32/63723/"));
                    busStopList.Add(new BusStop("C", "63725", "Opposite Canteen 2", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/33/63725/"));
                    busStopList.Add(new BusStop("C", "63727", "Hall 6 and Opp Hall 2", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/34/63727/"));
                    busStopList.Add(new BusStop("C", "63729", "Opposite Hall 1", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/3/35/63729/"));
                    break;

                case "D":
                    if (busStopList.Count != 0)
                    {
                        busStopList.Clear();
                    }

                    busStopList.Add(new BusStop("D", "22529", "Pioneer MRT", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/4/40/22529/"));
                    busStopList.Add(new BusStop("D", "27281", "Hall 1", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/4/3/27281/"));
                    busStopList.Add(new BusStop("D", "27291", "Opposite Hall 6", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/4/4/27291/"));
                    busStopList.Add(new BusStop("D", "27311", "Hall 2", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/4/5/27311/"));
                    busStopList.Add(new BusStop("D", "63735", "Student Services Centre", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/4/37/63735/"));
                    busStopList.Add(new BusStop("D", "63737", "Administration Building", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/4/38/63737/"));
                    busStopList.Add(new BusStop("D", "63725", "Opposite Canteen 2", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/4/33/63725/"));
                    busStopList.Add(new BusStop("D", "63727", "Hall 6 and Opp Hall 2", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/4/34/63727/"));
                    busStopList.Add(new BusStop("D", "63729", "Opposite Hall 1", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/4/35/63729/"));
                    busStopList.Add(new BusStop("D", "63739", "School of ADM", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/6/63739/"));
                    busStopList.Add(new BusStop("D", "27211", "Lee Wee Nam Library", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/7/27211/"));
                    busStopList.Add(new BusStop("D", "27221", "School of CEE", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/8/27221/"));
                    busStopList.Add(new BusStop("D", "63741", "School of Biological Sciences", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/9/63741/"));
                    busStopList.Add(new BusStop("D", "27231", "School of Comms Studies", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/10/27231/"));
                    busStopList.Add(new BusStop("D", "27241", "Hall 7", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/11/27241/"));
                    busStopList.Add(new BusStop("D", "27251", "Innovation Centre", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/12/27251/"));
                    busStopList.Add(new BusStop("D", "27261", "Hall 4", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/1/27261/"));
                    busStopList.Add(new BusStop("D", "63747", "Hall 5", "http://campusbus.ntu.edu.sg/ntubus/index.php/m/main/geteta/1/2/63747/"));
                    break;

                case "demo":
                    if (busStopList.Count != 0)
                    {
                        busStopList.Clear();
                    }
                    busStopList.Add(new BusStop("ABCD", "00000", "Demo Bus Stop", ""));
                    break;
            }
        }
    }
}

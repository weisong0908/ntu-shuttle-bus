﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using MahApps.Metro.Controls;
using MahApps.Metro;
using System.Net;
using System.IO;
using System.IO.IsolatedStorage;
using System.Xml;
using System.Xml.Serialization;

namespace Cherudim
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow: MetroWindow
    {
        //Global variables

        BusStops currentBusStopList;
        BusStop currentBusStop;
        FavBusStop favouritingBusStop;
        FavBusStop favBusStopSelected;
        List<FavBusStop> favouriteBusStopList = new List<FavBusStop>();
        int favPosition;
        WebClient busStopWebpage;

        bool isFavourited = false;

        public MainWindow()
        {
            InitializeComponent();

            try
            {
                favouriteBusStopList = readFavourite();
                favouriteListBox.ItemsSource = null;
                favouriteListBox.ItemsSource = favouriteBusStopList;
            }
            catch { }
        }

        //When user clicks the about button, show the about dialog
        private void aboutButton_Click(object sender, RoutedEventArgs e)
        {
            AboutWindow.ShowBox();
        }

        //Step 1: Bus type
        private void BusA_Selected(object sender, RoutedEventArgs e)
        {
            //MessageBoxWindow.ShowBox("A is selected");
            currentBusStopList = new BusStops("A");
            busStopListBox.ItemsSource = null;
            busStopListBox.ItemsSource = currentBusStopList.busStopList;

            busTypeTextBlock.Text = "A";
            busTypeTextBlock.Opacity = 1;
            busStopIDTextBlock.Text = "Bus stop ID";
            busStopIDTextBlock.Opacity = 0.3;
            busStopDetailsTextBlock.Text = "Bus stop details";
            busStopDetailsTextBlock.Opacity = 0.3;
        }

        private void BusB_Selected(object sender, RoutedEventArgs e)
        {
            //MessageBoxWindow.ShowBox("B is selected");
            currentBusStopList = new BusStops("B");
            busStopListBox.ItemsSource = null;
            busStopListBox.ItemsSource = currentBusStopList.busStopList;

            busTypeTextBlock.Text = "B";
            busTypeTextBlock.Opacity = 1;
            busStopIDTextBlock.Text = "Bus stop ID";
            busStopIDTextBlock.Opacity = 0.3;
            busStopDetailsTextBlock.Text = "Bus stop details";
            busStopDetailsTextBlock.Opacity = 0.3;
        }

        private void BusC_Selected(object sender, RoutedEventArgs e)
        {
            //MessageBoxWindow.ShowBox("C is selected");
            currentBusStopList = new BusStops("C");
            busStopListBox.ItemsSource = null;
            busStopListBox.ItemsSource = currentBusStopList.busStopList;

            busTypeTextBlock.Text = "C";
            busTypeTextBlock.Opacity = 1;
            busStopIDTextBlock.Text = "Bus stop ID";
            busStopIDTextBlock.Opacity = 0.3;
            busStopDetailsTextBlock.Text = "Bus stop details";
            busStopDetailsTextBlock.Opacity = 0.3;
        }

        private void BusD_Selected(object sender, RoutedEventArgs e)
        {
            //MessageBoxWindow.ShowBox("D is selected");
            currentBusStopList = new BusStops("D");
            busStopListBox.ItemsSource = null;
            busStopListBox.ItemsSource = currentBusStopList.busStopList;

            busTypeTextBlock.Text = "D";
            busTypeTextBlock.Opacity = 1;
            busStopIDTextBlock.Text = "Bus stop ID";
            busStopIDTextBlock.Opacity = 0.3;
            busStopDetailsTextBlock.Text = "Bus stop details";
            busStopDetailsTextBlock.Opacity = 0.3;
        }
        //End of step 1

        //Step 2: Bus stop
        private void busStopListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (busStopListBox.SelectedItem == null)
            {
                return;
            }

            isFavourited = false;
            ImageSourceValueSerializer sourceConverter = new ImageSourceValueSerializer();
            favouriteButtonImage.Source = (ImageSource)sourceConverter.ConvertFromString("Add_To_Favorties_Icon.png", null);

            currentBusStop = (BusStop)busStopListBox.SelectedItem;

            busStopIDTextBlock.Text = currentBusStop.busStopID;
            busStopIDTextBlock.Opacity = 1;
            busStopDetailsTextBlock.Text = currentBusStop.busStopDetails;
            busStopDetailsTextBlock.Opacity = 1;

            statusProgressBar.IsIndeterminate = true;
            statusTextBlock.Text = "retrieving data from internet..";

            busStopWebpage = new WebClient();
            busStopWebpage.DownloadStringCompleted += new DownloadStringCompletedEventHandler(busStopWebpage_DownloadStringCompleted);

            busTimeTextBlock.Text = "";
            busTimeDetailsTextBlock.Text = "connecting..";

            busStopWebpage.DownloadStringAsync(new Uri(currentBusStop.busStopUri));

            //check whether it is already in favourite list
            try
            {
                favouriteBusStopList = readFavourite();

                foreach (FavBusStop busStopInSearch in favouriteBusStopList)
                {
                    if (busStopInSearch.busStopID == currentBusStop.busStopID && busStopInSearch.busType == currentBusStop.busType)
                    {
                        isFavourited = true;
                        favPosition = favouriteBusStopList.IndexOf(busStopInSearch);
                        favouriteButtonImage.Source = (ImageSource)sourceConverter.ConvertFromString("Remove_From_Favorties_Icon.png", null);
                    }
                }
            }

            catch { }

            favouriteButton.IsEnabled = true;
        }

        void busStopWebpage_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            string busRemainingTime = "ConnectionFailure";

            try
            {
                busRemainingTime = GetRemainingTimeFromHTMLCodes(e.Result.ToString(), currentBusStop.busType);
            }

            //If connection fail
            catch
            {
                MessageBoxWindow.ShowBox("Please check your internet connection. Without internet connection, bus remaining time cannot be shown.", "No internet connection");
                //MessageBox.Show("Please check your internet connection. Without internet connection, bus remaining time cannot be shown.", "No internet connection", MessageBoxButton.OK);
            }

            switch (busRemainingTime)
            {
                case "ConnectionFailure":
                    busTimeTextBlock.Text = "X";
                    busTimeDetailsTextBlock.Text = "connection failure";
                    break;
                //if the character read is 1
                case "1":
                    busTimeTextBlock.Text = "1";
                    busTimeDetailsTextBlock.Text = "minute remaining";
                    break;
                //if the character read is A for arriving
                case "A":
                    busTimeTextBlock.Text = "!";
                    busTimeDetailsTextBlock.Text = "Arriving";
                    break;
                //if the character read is N for Not available
                case "N":
                    busTimeTextBlock.Text = "-";
                    busTimeDetailsTextBlock.Text = "service not available";
                    break;
                //if the character read is numbers then use the defailt behaviour
                default:
                    busTimeTextBlock.Text = busRemainingTime;
                    busTimeDetailsTextBlock.Text = "minutes remaining";
                    break;
            }

            refreshButton.IsEnabled = true;
            
            statusProgressBar.IsIndeterminate = false;
            statusTextBlock.Text = "ready";
        }
        //End of step 2

        //Using favourite tab
        private void favouriteListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (favouriteListBox.SelectedItem == null)
            {
                return;
            }

            favBusStopSelected = (FavBusStop)favouriteListBox.SelectedItem;
            currentBusStop = new BusStop(favBusStopSelected.busType, favBusStopSelected.busStopID, favBusStopSelected.busStopDetails, favBusStopSelected.busStopUri);

            isFavourited = true;
            ImageSourceValueSerializer sourceConverter = new ImageSourceValueSerializer();
            favouriteButtonImage.Source = (ImageSource)sourceConverter.ConvertFromString("Remove_From_Favorties_Icon.png", null);
            favouriteButton.IsEnabled = true;

            busStopIDTextBlock.Text = currentBusStop.busStopID;
            busStopIDTextBlock.Opacity = 1;
            busStopDetailsTextBlock.Text = currentBusStop.busStopDetails;
            busStopDetailsTextBlock.Opacity = 1;

            statusProgressBar.IsIndeterminate = true;
            statusTextBlock.Text = "retrieving data from internet..";

            busStopWebpage = new WebClient();
            busStopWebpage.DownloadStringCompleted += new DownloadStringCompletedEventHandler(busStopWebpage_DownloadStringCompleted);

            busTimeTextBlock.Text = "";
            busTimeDetailsTextBlock.Text = "connecting..";

            busStopWebpage.DownloadStringAsync(new Uri(currentBusStop.busStopUri));
        }
        //End of using favourite tab

        //Refresh button
        private void refreshButton_Click(object sender, RoutedEventArgs e)
        {
            statusProgressBar.IsIndeterminate = true;
            statusTextBlock.Text = "retrieving data from internet..";

            busStopWebpage = new WebClient();
            busStopWebpage.DownloadStringCompleted += new DownloadStringCompletedEventHandler(busStopWebpage_DownloadStringCompleted);

            busTimeTextBlock.Text = "";
            busTimeDetailsTextBlock.Text = "connecting..";

            busStopWebpage.DownloadStringAsync(new Uri(currentBusStop.busStopUri));
        }

        //favourite button
        private void favouriteButton_Click(object sender, RoutedEventArgs e)
        {
            favouritingBusStop = new FavBusStop();
            favouritingBusStop.busType = currentBusStop.busType;
            favouritingBusStop.busStopID = currentBusStop.busStopID;
            favouritingBusStop.busStopDetails = currentBusStop.busStopDetails;
            favouritingBusStop.busStopUri = currentBusStop.busStopUri;

            try
            {
                favouriteBusStopList = readFavourite();
            }
            catch { }


            if (isFavourited == false)
            {
                //MessageBoxWindow.ShowBox("isFavourited == false");
                favouriteBusStopList.Add(favouritingBusStop);
                saveFavourite(favouriteBusStopList);

                ImageSourceValueSerializer sourceConverter = new ImageSourceValueSerializer();
                favouriteButtonImage.Source = (ImageSource)sourceConverter.ConvertFromString("Remove_From_Favorties_Icon.png", null);
                isFavourited = true;

                try
                {
                    favouriteBusStopList = readFavourite();
                    favouriteListBox.ItemsSource = null;
                    favouriteListBox.ItemsSource = favouriteBusStopList;

                    //MessageBoxWindow.ShowBox(favouriteBusStopList.Count.ToString());
                }
                catch { }
            }

            else if (isFavourited == true)
            {
                //MessageBoxWindow.ShowBox("isFavourited == true");
                favouriteBusStopList.RemoveAt(favPosition);
                saveFavourite(favouriteBusStopList);

                ImageSourceValueSerializer sourceConverter = new ImageSourceValueSerializer();
                favouriteButtonImage.Source = (ImageSource)sourceConverter.ConvertFromString("Add_To_Favorties_Icon.png", null);
                isFavourited = false;

                try
                {
                    favouriteBusStopList = readFavourite();
                    favouriteListBox.ItemsSource = null;
                    favouriteListBox.ItemsSource = favouriteBusStopList;

                    //MessageBoxWindow.ShowBox(favouriteBusStopList.Count.ToString());
                }
                catch { }
                
            }
        }

        ///////////////////////////////////////////////////////////////////////////
        //Methods:
        
        //Use substring to extract the important character
        public string GetRemainingTimeFromHTMLCodes(string htmlCodes, string busType)
        {
            //find body tag
            int bodyPositionStart = htmlCodes.IndexOf("<body>", 0);

            string body = htmlCodes.Substring(bodyPositionStart + 5, 150);

            int busInfoPosition = body.IndexOf("NTU-" + busType, 0) + 21;

            if (busInfoPosition == 20)
            {
                return "N";
            }

            else
            {
                return body.Substring(busInfoPosition, 1);
            }
        }

        //Save bus stop to favourite bus stop in Isolated File Storage
        public void saveFavourite(List<FavBusStop> busStopList)
        {
            XmlWriterSettings writerSettings = new XmlWriterSettings();
            writerSettings.Indent = true;

            using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForAssembly()) //.GetUserStoreForApplication())
            {
                using (IsolatedStorageFileStream rawStream = isf.CreateFile("favBusStops.xml"))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(List<FavBusStop>));

                    using (XmlWriter writer = XmlWriter.Create(rawStream, writerSettings))
                    {
                        serializer.Serialize(writer, busStopList);
                        writer.Close();
                    }
                }
            }
        }

        //Read bus stop from favourite bus stop in Isolated File Storage
        public List<FavBusStop> readFavourite()
        {
            using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForAssembly()) //.GetUserStoreForApplication())
            {
                using (IsolatedStorageFileStream rawStream = isf.OpenFile("favBusStops.xml", FileMode.Open, FileAccess.Read))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(List<FavBusStop>));

                    List<FavBusStop> busStopList = (List<FavBusStop>)serializer.Deserialize(rawStream);

                    return busStopList;
                }
            }
        }

        //End of methods
        ///////////////////////////////////////////////////////////////////////////

        
    }
}

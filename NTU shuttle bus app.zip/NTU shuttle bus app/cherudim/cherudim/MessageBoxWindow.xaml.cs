﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MahApps.Metro.Controls;
using MahApps.Metro;

namespace Cherudim
{
    /// <summary>
    /// Interaction logic for MessageBoxWindow.xaml
    /// </summary>
    public partial class MessageBoxWindow : MetroWindow
    {
        static MessageBoxWindow messageBoxWindow;

        public MessageBoxWindow()
        {
            InitializeComponent();
        }

        public static void ShowBox(string message)
        {
            messageBoxWindow = new MessageBoxWindow();
            messageBoxWindow.MessageTextBlock.Text = message;
            messageBoxWindow.ShowDialog();
        }

        public static void ShowBox(string message, string title)
        {
            messageBoxWindow = new MessageBoxWindow();
            messageBoxWindow.MessageTextBlock.Text = message;
            messageBoxWindow.Title = title;
            messageBoxWindow.ShowDialog();
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

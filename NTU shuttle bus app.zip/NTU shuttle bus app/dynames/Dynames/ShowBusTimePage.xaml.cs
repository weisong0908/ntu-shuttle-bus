﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

using System.IO;
using System.IO.IsolatedStorage;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Phone.Shell;

namespace Dynames
{
    public partial class ShowBusTimePage : PhoneApplicationPage
    {
        BusStop busStopSelected;
        string busType;
        string busStopID;
        string busStopDetails;
        string uri;

        WebClient busStopWebpage;
        WebClient refreshBusStopWebpage;

        bool isFavourited = false;
        int favPosition;

        public ShowBusTimePage()
        {
            InitializeComponent();

            //check favourite bus stop
            App thisApp = Application.Current as App;
            List<FavBusStop> favouriteBusStopList = new List<FavBusStop>();

            try
            {
                //read favourite bus stop from isolated storage file
                favouriteBusStopList = readFavourite();

                //if the active bus stop is already in the favourite bus stop list, then change the favourite button to "remove from favourite"
                foreach (FavBusStop searchBusStop in favouriteBusStopList)
                {
                    if (searchBusStop.busStopID == thisApp.ActiveBusStopSelected.busStopID && searchBusStop.busType == thisApp.ActiveBusStopSelected.busType)
                    {
                        isFavourited = true;
                        favPosition = favouriteBusStopList.IndexOf(searchBusStop);

                        ApplicationBarIconButton favButton = (ApplicationBarIconButton)ApplicationBar.Buttons[0];
                        favButton.IconUri = new Uri("Remove_From_Favorties_Icon.png", UriKind.RelativeOrAbsolute);
                        favButton.Text = "Removed from favourite";
                    }
                }
            }
            catch { }
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            //base.OnNavigatedTo(e);

            //use webclient to download webpage from ntu campus bus mobile site
            busStopWebpage = new WebClient();
            busStopWebpage.DownloadStringCompleted += new DownloadStringCompletedEventHandler(busStopWebpage_DownloadStringCompleted);

            App thisApp = Application.Current as App;

            busStopSelected = thisApp.ActiveBusStopSelected;
            busType = busStopSelected.busType;
            busStopID = busStopSelected.busStopID;
            busStopDetails = busStopSelected.busStopDetails;
            uri = busStopSelected.busStopUri;


            busTypeTextBlock.Text = "Bus " + busType + " " + busStopID;
            busDetailsTextBlock.Text = busStopDetails;
            info1TextBlock.Text = "";
            info2TextBlock.Text = "connecting..";

            //start downloading the content
            busStopWebpage.DownloadStringAsync(new Uri(uri));
        }

        //If favourite bus stop is clicked
        private void favouriteButton_Click(object sender, EventArgs e)
        {
            App thisApp = Application.Current as App;
            List<FavBusStop> favouriteBusStopList = new List<FavBusStop>();

            FavBusStop favBusStop = new FavBusStop();
            favBusStop.busType = thisApp.ActiveBusStopSelected.busType;
            favBusStop.busStopID = thisApp.ActiveBusStopSelected.busStopID;
            favBusStop.busStopDetails = thisApp.ActiveBusStopSelected.busStopDetails;
            favBusStop.busStopUri = thisApp.ActiveBusStopSelected.busStopUri;

            //Read the favourite bus stop from isolated file storage
            try
            {
                favouriteBusStopList = readFavourite();
            }

            catch { }

            //If the active bus stop is NOT FAVOURITED
            if (isFavourited == false)
            {
                //Add this active bus stop in Isolated File Storage
                favouriteBusStopList.Add(favBusStop);
                saveFavourite(favouriteBusStopList);

                //Change the favourite button icon to "remove from favourite"
                ApplicationBarIconButton favButton = (ApplicationBarIconButton)ApplicationBar.Buttons[0];
                favButton.IconUri = new Uri("Remove_From_Favorties_Icon.png", UriKind.RelativeOrAbsolute);
                favButton.Text = "Remove from favourite";
                isFavourited = true;
            }

            //If the active bus stop IS FAVOURITED
            else if (isFavourited == true)
            {
                //Remove the active bus stop from favourite bus stop list
                favouriteBusStopList.RemoveAt(favPosition);
                saveFavourite(favouriteBusStopList);

                //Change the favourite button icon to "add to favourite"
                ApplicationBarIconButton favButton = (ApplicationBarIconButton)ApplicationBar.Buttons[0];
                favButton.IconUri = new Uri("Add_To_Favorties_Icon.png", UriKind.RelativeOrAbsolute);
                favButton.Text = "Add to favourite";
                isFavourited = false;
            }
        }

        //Download the webpage again to read the latest content
        private void refreshButton_Click(object sender, EventArgs e)
        {
            refreshBusStopWebpage = new WebClient();
            refreshBusStopWebpage.DownloadStringCompleted += new DownloadStringCompletedEventHandler(busStopWebpage_DownloadStringCompleted);

            try
            {
                App thisApp = Application.Current as App;

                busStopSelected = thisApp.ActiveBusStopSelected;
                busType = busStopSelected.busType;
                busStopID = busStopSelected.busStopID;
                busStopDetails = busStopSelected.busStopDetails;
                uri = busStopSelected.busStopUri;


                busTypeTextBlock.Text = "Bus " + busType + " " + busStopID;
                busDetailsTextBlock.Text = busStopDetails;
                info1TextBlock.Text = "";
                info2TextBlock.Text = "connecting..";

                refreshBusStopWebpage.DownloadStringAsync(new Uri(uri));
            }
            catch { }
        }

        //read the content and tell user the bus status
        void busStopWebpage_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            string busRemainingTime = "ConnectionFailure";

            try
            {
                busRemainingTime = GetRemainingTimeFromHTMLCodes(e.Result.ToString(), busType);
            }

            //If connection fail
            catch
            {
                MessageBox.Show("Please check your internet connection. Without internet connection, bus remaining time cannot be shown.", "No internet connection", MessageBoxButton.OK);
            }

            switch (busRemainingTime)
            {
                case "ConnectionFailure":
                    info1TextBlock.Text = "x";
                    info2TextBlock.Text = "connection failure";
                    break;
                //if the character read is 1
                case "1":
                    info1TextBlock.Text = "1";
                    info2TextBlock.Text = "minute remaining";
                    break;
                //if the character read is A for arriving
                case "A":
                    info1TextBlock.Text = "!";
                    info2TextBlock.Text = "Arriving";
                    break;
                //if the character read is N for Not available
                case "N":
                    info1TextBlock.Text = "-";
                    info2TextBlock.Text = "service not available";
                    break;
                //if the character read is numbers then use the defailt behaviour
                default:
                    info1TextBlock.Text = busRemainingTime;
                    info2TextBlock.Text = "minutes remaining";
                    break;
            }
        }

        //Use substring to extract the important character
        public string GetRemainingTimeFromHTMLCodes(string htmlCodes, string busType)
        {
            //find body tag
            int bodyPositionStart = htmlCodes.IndexOf("<body>", 0);

            string body = htmlCodes.Substring(bodyPositionStart + 5, 150);

            int busInfoPosition = body.IndexOf("NTU-" + busType, 0) + 21;

            if (busInfoPosition == 20)
            {
                return "N";
            }

            else
            {
                return body.Substring(busInfoPosition, 1);
            }
        }

        //Save bus stop to favourite bus stop in Isolated File Storage
        public void saveFavourite(List<FavBusStop> busStopList)
        {
            XmlWriterSettings writerSettings = new XmlWriterSettings();
            writerSettings.Indent = true;

            using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (IsolatedStorageFileStream rawStream = isf.CreateFile("favBusStops.xml"))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(List<FavBusStop>));

                    using (XmlWriter writer = XmlWriter.Create(rawStream, writerSettings))
                    {
                        serializer.Serialize(writer, busStopList);
                        writer.Close();
                    }
                }
            }
        }

        //Read bus stop from favourite bus stop in Isolated File Storage
        public List<FavBusStop> readFavourite()
        {
            using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (IsolatedStorageFileStream rawStream = isf.OpenFile("favBusStops.xml", FileMode.Open, FileAccess.Read))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(List<FavBusStop>));

                    List<FavBusStop> busStopList = (List<FavBusStop>)serializer.Deserialize(rawStream);

                    return busStopList;
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Collections.ObjectModel;

namespace Dynames
{
    public partial class ChooseBusStopPage : PhoneApplicationPage
    {
        public ChooseBusStopPage()
        {
            InitializeComponent();
        }

        string busTypeSelected = "";
        ObservableCollection<BusStop> observableBusStops;

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            //Show bus stop list when this page is navigated to

            App thisApp = Application.Current as App;
            busTypeSelected = thisApp.ActiveBusTypeSelected;

            BusStops busStopListSelected = new BusStops(busTypeSelected);

            observableBusStops = new ObservableCollection<BusStop>(thisApp.ActiveBusStopListSelected.busStopList);

            busStopListBox.ItemsSource = observableBusStops;

            //Change the page title to show the bus service selected
            PageTitle.Text = "bus service " + busTypeSelected;
        }        

        //If a bus stop is selected, then assign it to be the active bus stop and navigate to bus time remaining page
        private void busStopListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (busStopListBox.SelectedItem == null) return;

            BusStop busStopSelected = (BusStop)busStopListBox.SelectedItem;

            App thisApp = Application.Current as App;
            thisApp.ActiveBusStopSelected = busStopSelected;

            NavigationService.Navigate(new Uri("/ShowBusTimePage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
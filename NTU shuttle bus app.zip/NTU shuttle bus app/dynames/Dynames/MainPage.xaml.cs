﻿/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////  Created by: Teng Wei Song (weisong0908@hotmail.com)  ////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

using Microsoft.Phone.Net.NetworkInformation;
using System.IO.IsolatedStorage;
using System.Collections.ObjectModel;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using Microsoft.Phone.Tasks;

namespace Dynames
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            //check connection only once when this app is launched
            bool is3GAvailable = DeviceNetworkInformation.IsCellularDataEnabled;
            bool isWifiAvailable = DeviceNetworkInformation.IsWiFiEnabled;

            if (is3GAvailable == false && isWifiAvailable == false)
            {
                MessageBox.Show("Please check your internet connection. Without internet connection, bus remaining time cannot be shown.", "No internet connection", MessageBoxButton.OK);
            }

            // Set the data context of the listbox control to the sample data
            DataContext = App.ViewModel;
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);

            //about this app
            versionTextBlock.Text = "App version: 1.1";
            aboutTextBlock.Text = "This app provides a quick and easy way to check the remaining time of any NTU shuttle bus reaching their respecting bus stops." + Environment.NewLine + Environment.NewLine + "Tap any bus service and then choose the desired bus stop to get the remaining time.";
        }

        // Load data for the ViewModel Items
        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            if (!App.ViewModel.IsDataLoaded)
            {
                App.ViewModel.LoadData();
            }
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            //load favourite list when this page is navigated to
            try
            {
                favouriteListBox.ItemsSource = readFavourite();

                //Show some simple instruction on first load when there is no favourited item
                if (favouriteListBox.Items.Count == 0)
                {
                    favtextBlock.Visibility = System.Windows.Visibility.Visible;
                }

                //hide the instruction when there is favourited items
                if (favouriteListBox.Items.Count != 0)
                {
                    favtextBlock.Visibility = System.Windows.Visibility.Collapsed;
                }
            }
            catch { }
        }

        //Panaroma item 1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Favourite list
        //When a bus stop in favourite bus stop list is selected, assign the selected bus stop to active bus stop and go to show bus remaining time page
        private void favouriteListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (favouriteListBox.SelectedItem == null) return;

            App thisapp = Application.Current as App;

            FavBusStop favBusStopSelected = (FavBusStop)favouriteListBox.SelectedItem;
            thisapp.ActiveBusStopSelected = new BusStop(favBusStopSelected.busType, favBusStopSelected.busStopID, favBusStopSelected.busStopDetails, favBusStopSelected.busStopUri);

            //thisapp.ActiveBusStopSelected.busType = favBusStopSelected.busType;
            //thisapp.ActiveBusStopSelected.busStopID = favBusStopSelected.busStopID;
            //thisapp.ActiveBusStopSelected.busStopDetails = favBusStopSelected.busStopDetails;
            //thisapp.ActiveBusStopSelected.busStopUri = favBusStopSelected.busStopUri;

            NavigationService.Navigate(new Uri("/ShowBusTimePage.xaml", UriKind.RelativeOrAbsolute));
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //Paranoma item 2//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Choose Bus Type to start with
        private void busAImage_Tap(object sender, GestureEventArgs e)
        {
            App thisApp = Application.Current as App;
            thisApp.ActiveBusTypeSelected = "A";
            thisApp.ActiveBusStopListSelected = new BusStops(thisApp.ActiveBusTypeSelected);
            NavigationService.Navigate(new Uri("/ChooseBusStopPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void busBImage_Tap(object sender, GestureEventArgs e)
        {
            App thisApp = Application.Current as App;
            thisApp.ActiveBusTypeSelected = "B";
            thisApp.ActiveBusStopListSelected = new BusStops(thisApp.ActiveBusTypeSelected);
            NavigationService.Navigate(new Uri("/ChooseBusStopPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void busCImage_Tap(object sender, GestureEventArgs e)
        {
            App thisApp = Application.Current as App;
            thisApp.ActiveBusTypeSelected = "C";
            thisApp.ActiveBusStopListSelected = new BusStops(thisApp.ActiveBusTypeSelected);
            NavigationService.Navigate(new Uri("/ChooseBusStopPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void busDImage_Tap(object sender, GestureEventArgs e)
        {
            App thisApp = Application.Current as App;
            thisApp.ActiveBusTypeSelected = "D";
            thisApp.ActiveBusStopListSelected = new BusStops(thisApp.ActiveBusTypeSelected);
            NavigationService.Navigate(new Uri("/ChooseBusStopPage.xaml", UriKind.RelativeOrAbsolute));
        }

        //for testing use
        /*private void recDemo_Tap(object sender, GestureEventArgs e)
        {
            App thisApp = Application.Current as App;
            thisApp.ActiveBusTypeSelected = "D";
            thisApp.ActiveBusStopListSelected = new BusStops(thisApp.ActiveBusTypeSelected);

            NavigationService.Navigate(new Uri("/ChooseBusStopPage.xaml", UriKind.RelativeOrAbsolute));
        }*/
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        //read from isolated storage file for favourite bus stop
        public List<FavBusStop> readFavourite()
        {
            using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (IsolatedStorageFileStream rawStream = isf.OpenFile("favBusStops.xml", FileMode.Open, FileAccess.Read))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(List<FavBusStop>));

                    List<FavBusStop> busStopList = (List<FavBusStop>)serializer.Deserialize(rawStream);

                    return busStopList;
                }
            }
        }

        //Rate and review in Marketplace
        private void rateMeButton_Click(object sender, RoutedEventArgs e)
        {
            MarketplaceReviewTask review = new MarketplaceReviewTask();
            review.Show();
        }
    }
}